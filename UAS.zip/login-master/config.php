<?php
/*
 * variabel koneksi
 ***/
$db_host	= 'localhost';
$db_port	= '3306';
$db_name	= 'test';
$db_user	= 'root';
$db_pass	= '';

