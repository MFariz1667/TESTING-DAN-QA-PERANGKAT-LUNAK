from .test_models import create_factory

create_factory()